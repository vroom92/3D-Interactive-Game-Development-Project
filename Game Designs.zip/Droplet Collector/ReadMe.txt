
=============================================== 
              Droplet Collector
===============================================

System Requirements
	
�Desktop: �OS: Windows XP+, Mac OS X 10.7+, Ubuntu 10.10+, SteamOS+

�Graphics card: DX9 (shader model 2.0) capabilities; generally everything made since 2004 should work.

�CPU: SSE2 instruction set support.


Game Instructions:-

1) Double Click the game icon to start the game.

2) Select appropriate screen resolution and graphics quality as per need.

3) Select appropriate options from the Main Menu ie Play, Instructions, Quit.

4) Objective - Collect droplets to increase score and avoid thunders which decreases lives.

5) Player Cotrols - Single player game, player can use LEFT and RIGHT keys to move the bucket in desired direction.

6) For any further game related queries send a mail to gaming_portal@developers.com