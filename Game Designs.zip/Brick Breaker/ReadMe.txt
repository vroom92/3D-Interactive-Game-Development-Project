
=============================================== 
              Brick Breaker 
===============================================

System Requirements
	
�Desktop: �OS: Windows XP+, Mac OS X 10.7+, Ubuntu 10.10+, SteamOS+

�Graphics card: DX9 (shader model 2.0) capabilities; generally everything made since 2004 should work.

�CPU: SSE2 instruction set support.


Game Instructions:-

1) Double Click the game icon to start the game.

2) Select appropriate screen resolution and graphics quality as per need.

3) Select appropriate options from the Main Menu ie Play, Instructions, Quit.

4) Objective - Do not let the ball fall off the racket while it breaks the bricks and bounces back to the racket.

5) Player Cotrols - Single player game, player can use LEFT and RIGHT arrow keys to 

   move the racket in the respective directions.

6) For any further game related queries send a mail to gaming_portal@developers.com