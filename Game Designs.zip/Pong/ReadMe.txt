============== 2D Pong Game ============

System Requirements
	
�Desktop: �OS: Windows XP+, Mac OS X 10.7+, Ubuntu 10.10+, SteamOS+

�Graphics card: DX9 (shader model 2.0) capabilities; generally everything made since 2004 should work.

�CPU: SSE2 instruction set support.


Game Instructions:-

1) Double Click the game icon to start the game.

2) Select appropriate screen resolution and graphics quality as per need.

3) Select appropriate options from the Main Menu.

4) Objective - Beat your opponent by making the ball touch on the wall on your opponent's side.

5) Player 1 Controls - Up and Down arrow keys.

6) Player 2 Controls - W and S keys.

7) For any further game related queries send a mail to gaming_portal@developers.com

============== 2D Pong Game ============